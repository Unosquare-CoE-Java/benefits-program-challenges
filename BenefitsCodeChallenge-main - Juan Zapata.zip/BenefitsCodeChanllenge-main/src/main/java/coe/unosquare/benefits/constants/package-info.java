/*
 * package-info.java
 * 1.0
 * 2023-02-10
 * Copyright 2023 Unosquare
 * Any illegal reproduction of this content will result in immediate legal action.
 */

/**
 * This package contains different constants to be used across the solution
 *
 * @author Juan Zapata
 * @version 1.0
 */

package coe.unosquare.benefits.constants;
