package coe.unosquare.benefits.common.consts;

/**
 * The payment type constants
 */
public class PaymentType {
    public static final String VISA = "Visa";
    public static final String MASTER_CARD = "Mastercard";
}
