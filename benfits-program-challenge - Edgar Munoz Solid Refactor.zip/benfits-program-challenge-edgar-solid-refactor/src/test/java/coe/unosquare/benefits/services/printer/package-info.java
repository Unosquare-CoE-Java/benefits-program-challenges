/*
 * package-info.java
 * 1.0
 * 2023-01-14
 * Copyright 2022 Unosquare
 * Any illegal reproduction of this content will result in immediate legal action.
 */

/**
 * This package contains all classes related to the printer tests.
 *
 * @author Edgar Munoz
 * @version 1.0
 */

package coe.unosquare.benefits.services.printer;