## Coding Challenge Refactor


## Overview

This a refactor of https://github.com/emmanuel-huitrado/benefits-program-challenge

### Prerequisites:

- Java 17
- Maven

### Build

To build the application run

```Bash
mvn clean install
```

### Run tests

```bash
mvn test
```

The API test suite consists of 16 tests:

- Unit tests for very specific code functionality, and it is related to business logic. Can be executed just by using a @Test annotation and runs in complete isolation.
  - calculateVisa7ProductsDiscountTest
  - testCalculateMasterCardDiscount_greaterThan100
  - masterCardDiscount_withSubtotalBetween75And99_returnsDiscountOf12Percent
  - testCalculateDiscount_withValidPaymentType_shouldReturnDiscount
  - testCalculateDiscount_withInvalidPaymentType_shouldThrowInvalidPaymentTypeException
  - calculateVisa10ProductsDiscountTest
  - orderWithVisaLessThan7ProductsDiscountTest
  - orderWithVisa7ProductsDiscountTest
  - orderWithVisa10ProductsDiscountTest
  - orderWithVisaMoreThan10ProductsDiscountTest
  - testPutOrder_throwsInvalidOrderException_whenOrderIdIsInvalid
  - orderWithMastercardDiscount
  - testProcessPayment_withInvalidOrderId_shouldThrowOrderNotFoundException
  - testProcessPayment_withValidInputs_shouldReturnPayment
  - testProcessPayment_withValidInput_shouldCreateNewPayment




