package com.unosquare.benefits.util;

import com.unosquare.benefits.entity.Order;
import com.unosquare.benefits.entity.OrderItem;
import com.unosquare.benefits.entity.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class OrderGenerator {

    private AtomicLong orderId = new AtomicLong(1);
    public Order generateOrder(List<Product> products, int numberOfOrderItems, Integer quantityPerItem) {
        Order order = new Order();
        order.setId(orderId.getAndIncrement());
        List<OrderItem> orderItems = new ArrayList<>();
        Random random = new Random();

        orderItems = IntStream.range(0, numberOfOrderItems)
                .mapToObj(i -> {
                    Product product = products.get(random.nextInt(products.size()));
                    int itemQuantity = quantityPerItem != null ? quantityPerItem : random.nextInt(10) + 1;
                    return new OrderItem(product, itemQuantity);
                })
                .collect(Collectors.toList());

        order.setOrderItems(orderItems);
        return order;
    }

}
