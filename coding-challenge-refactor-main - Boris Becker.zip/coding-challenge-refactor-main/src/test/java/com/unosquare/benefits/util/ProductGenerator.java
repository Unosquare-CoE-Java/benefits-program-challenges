package com.unosquare.benefits.util;

import com.github.javafaker.Faker;
import com.unosquare.benefits.entity.Product;
import com.unosquare.benefits.enums.ProductType;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ProductGenerator {

    public List<Product> generateProducts(Integer expectedSize) {
        Faker faker = new Faker();
        Random random = new Random();
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        return IntStream.range(0, expectedSize)
                .mapToObj(i -> {
                    Product product = new Product();
                    product.setName(faker.commerce().productName());
                    product.setPrice(new BigDecimal(decimalFormat.format(random.nextDouble() * 10.00)));
                    product.setProductType(ProductType.values()[random.nextInt(ProductType.values().length)]);
                    return product;
                })
                .collect(Collectors.toList());
    }
}
