package com.unosquare.benefits.services;

import com.unosquare.benefits.entity.Order;
import com.unosquare.benefits.entity.Payment;
import com.unosquare.benefits.entity.Product;
import com.unosquare.benefits.enums.PaymentType;
import com.unosquare.benefits.exceptions.InvalidOrderException;
import com.unosquare.benefits.exceptions.InvalidPaymentTypeException;
import com.unosquare.benefits.exceptions.OrderNotFoundException;
import com.unosquare.benefits.service.OrderManager;
import com.unosquare.benefits.service.PaymentManager;
import com.unosquare.benefits.util.OrderGenerator;
import com.unosquare.benefits.util.ProductGenerator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class PaymentManagerTest {

    private final ProductGenerator productGenerator = new ProductGenerator();

    private final OrderGenerator orderGenerator = new OrderGenerator();

    @Test
    public void testProcessPayment_withValidInput_shouldCreateNewPayment() throws InvalidPaymentTypeException, OrderNotFoundException, InvalidOrderException {
        List<Product> products = productGenerator.generateProducts(15);
        Order order = orderGenerator.generateOrder(products, 15, 1);
        OrderManager.instance().putOrder(order.getId(), order);
        PaymentManager paymentManager = new PaymentManager();
        Payment payment = paymentManager.processPayment(order.getId(), PaymentType.VISA);
        assertNotNull(payment);
        assertEquals(order.getId(), payment.getOrderId());
        assertEquals(PaymentType.VISA, payment.getPaymentType());
        assertEquals(OrderManager.instance().getFinalAmount(order, PaymentType.VISA), payment.getAmount());
        assertTrue(PaymentManager.instance().getPaymentMap().containsValue(payment));
    }

    @Test
    public void testProcessPayment_withInvalidOrderId_shouldThrowOrderNotFoundException() {
        OrderNotFoundException exception = Assertions.assertThrows(OrderNotFoundException.class, () -> {
            PaymentManager paymentService = new PaymentManager();
            paymentService.processPayment(999L, PaymentType.VISA);
        });
        Assertions.assertEquals("Order: 999 not found", exception.getMessage());
    }


    @Test
    public void testProcessPayment_withValidInputs_shouldReturnPayment(){
        List<Product> products = productGenerator.generateProducts(15);
        Order order = orderGenerator.generateOrder(products, 15, 1);
        order.setId(0L);

        InvalidOrderException exception = Assertions.assertThrows(InvalidOrderException.class, () -> {
            PaymentManager paymentService = new PaymentManager();
            paymentService.processPayment(order.getId(), PaymentType.VISA);
        });
        Assertions.assertEquals("Order: "+ order.getId() + " not found", exception.getMessage());
    }
    }
