package com.unosquare.benefits.services;

import com.unosquare.benefits.entity.Order;
import com.unosquare.benefits.entity.OrderItem;
import com.unosquare.benefits.entity.Product;
import com.unosquare.benefits.enums.PaymentType;
import com.unosquare.benefits.enums.ProductType;
import com.unosquare.benefits.exceptions.InvalidPaymentTypeException;
import com.unosquare.benefits.service.DiscountCalculator;
import com.unosquare.benefits.service.OrderManager;
import com.unosquare.benefits.util.OrderGenerator;
import com.unosquare.benefits.util.ProductGenerator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;


public class DiscountCalculatorTest {

    private final DiscountCalculator discountCalculator = new DiscountCalculator();
    private final ProductGenerator productGenerator = new ProductGenerator();

    private final OrderGenerator orderGenerator = new OrderGenerator();

    @Test
    public void calculateVisa10ProductsDiscountTest() {
        Order order = new Order();
        Product product1 = new Product();
        product1.setProductType(ProductType.BasicNeeds);
        product1.setName("product 1");
        product1.setPrice(new BigDecimal("1"));
        OrderItem orderItem1 = new OrderItem(product1, 10);
        order.setOrderItems(List.of(orderItem1));
        BigDecimal subtotal = new BigDecimal("100.00");

        BigDecimal discount = discountCalculator.calculateVisaDiscount(order, subtotal);
        discount = discount.setScale(2, RoundingMode.HALF_UP);

        Assertions.assertEquals(new BigDecimal("15.00"), discount);
    }

    @Test
    public void calculateVisa7ProductsDiscountTest() {
        Order order = new Order();
        Product product1 = new Product();
        product1.setProductType(ProductType.BasicNeeds);
        product1.setName("product 1");
        product1.setPrice(new BigDecimal("1"));
        OrderItem orderItem1 = new OrderItem(product1, 7);
        order.setOrderItems(List.of(orderItem1));
        BigDecimal subtotal = new BigDecimal("70.00");

        BigDecimal discount = discountCalculator.calculateVisaDiscount(order, subtotal);
        discount = discount.setScale(2, RoundingMode.HALF_UP);

        Assertions.assertEquals(new BigDecimal("7.00"), discount);
    }

    @Test
    public void testCalculateMasterCardDiscount_greaterThan100() {
        BigDecimal subtotal = new BigDecimal("120");
        BigDecimal expectedDiscount = new BigDecimal("20.40");
        BigDecimal actualDiscount = discountCalculator.calculateMasterCardDiscount(subtotal);
        actualDiscount = actualDiscount.setScale(2, RoundingMode.HALF_UP);
        Assertions.assertEquals(expectedDiscount, actualDiscount);
    }

    @Test
    public void masterCardDiscount_withSubtotalBetween75And99_returnsDiscountOf12Percent() {
        // Arrange
        BigDecimal subtotal = new BigDecimal("87.50");
        DiscountCalculator discountCalculator = new DiscountCalculator();

        // Act
        BigDecimal discount = discountCalculator.calculateMasterCardDiscount(subtotal);
        BigDecimal expectedDiscount = subtotal.multiply(new BigDecimal("0.12"));
        discount = discount.setScale(4, RoundingMode.HALF_UP);
        // Assert
        Assertions.assertEquals(expectedDiscount, discount);
    }

    @Test
    public void testCalculateDiscount_withInvalidPaymentType_shouldThrowInvalidPaymentTypeException() {
        Order order = new Order();
        BigDecimal subtotal = new BigDecimal("100");
        InvalidPaymentTypeException exception = Assertions.assertThrows(InvalidPaymentTypeException.class, () -> {
            DiscountCalculator calculator = new DiscountCalculator();
            calculator.calculateDiscount("invalid", subtotal, order);
        });
        Assertions.assertEquals("Invalid paymentType: invalid", exception.getMessage());
    }

    @Test
    public void testCalculateDiscount_withValidPaymentType_shouldReturnDiscount() {
        List<Product> products = productGenerator.generateProducts(15);
        Order order = orderGenerator.generateOrder(products, 15, 1);
        BigDecimal subtotal = OrderManager.instance().calculateSubtotal(order);
        DiscountCalculator calculator = new DiscountCalculator();
        try {
            BigDecimal visaDiscount = calculator.calculateDiscount("VISA", subtotal, order);
            BigDecimal masterCardDiscount = calculator.calculateDiscount("MASTERCARD", subtotal, order);
            BigDecimal cashDiscount = calculator.calculateDiscount("CASH", subtotal, order);
            // Assert that the returned discounts are not null
            Assertions.assertNotNull(visaDiscount);
            Assertions.assertNotNull(masterCardDiscount);
            Assertions.assertNotNull(cashDiscount);
            // Assertions for discounts
        } catch (InvalidPaymentTypeException e) {
            // exception handling
        }
    }




}
