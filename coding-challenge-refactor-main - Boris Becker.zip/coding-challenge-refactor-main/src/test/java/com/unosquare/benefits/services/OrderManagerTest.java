package com.unosquare.benefits.services;

import com.unosquare.benefits.entity.Order;
import com.unosquare.benefits.entity.Product;
import com.unosquare.benefits.enums.PaymentType;
import com.unosquare.benefits.exceptions.InvalidOrderException;
import com.unosquare.benefits.exceptions.InvalidPaymentTypeException;
import com.unosquare.benefits.service.OrderManager;
import com.unosquare.benefits.util.OrderGenerator;
import com.unosquare.benefits.util.ProductGenerator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;


public class OrderManagerTest {
 
    private final ProductGenerator productGenerator = new ProductGenerator();

    private final OrderGenerator orderGenerator = new OrderGenerator();

    @Test
    public void orderWithVisaMoreThan10ProductsDiscountTest() throws Exception {
        List<Product> products = productGenerator.generateProducts(15);
        Order order = orderGenerator.generateOrder(products, 15, 1);
        BigDecimal subtotal = OrderManager.instance().calculateSubtotal(order);
        BigDecimal discountedSubtotal = OrderManager.instance().getFinalAmount(order, PaymentType.VISA);
        BigDecimal discount = new BigDecimal(subtotal.subtract(discountedSubtotal).divide(subtotal)
                .setScale(2, RoundingMode.HALF_EVEN).toPlainString());
        Assertions.assertEquals(new BigDecimal("0.15"), discount);
    }

    @Test
    public void orderWithVisa10ProductsDiscountTest() throws InvalidPaymentTypeException {
        List<Product> products = productGenerator.generateProducts(10);
        Order order = orderGenerator.generateOrder(products, 10, 1);
        BigDecimal subtotal = OrderManager.instance().calculateSubtotal(order);
        BigDecimal discountedSubtotal = OrderManager.instance().getFinalAmount(order, PaymentType.VISA);
        BigDecimal discount = new BigDecimal(subtotal.subtract(discountedSubtotal).divide(subtotal)
                .setScale(2, RoundingMode.HALF_EVEN).toPlainString());
        Assertions.assertEquals(new BigDecimal("0.15"), discount);
    }

    @Test
    public void orderWithVisa7ProductsDiscountTest() throws InvalidPaymentTypeException {
        List<Product> products = productGenerator.generateProducts(7);
        Order order = orderGenerator.generateOrder(products, 7, 1);
        BigDecimal subtotal = OrderManager.instance().calculateSubtotal(order);
        BigDecimal discountedSubtotal = OrderManager.instance().getFinalAmount(order, PaymentType.VISA);
        BigDecimal discount = new BigDecimal(subtotal.subtract(discountedSubtotal).divide(subtotal)
                .setScale(2, RoundingMode.HALF_EVEN).toPlainString());
        Assertions.assertEquals(new BigDecimal("0.10"), discount);
    }

    @Test
    public void orderWithVisaLessThan7ProductsDiscountTest() throws InvalidPaymentTypeException {
        List<Product> products = productGenerator.generateProducts(5);
        Order order = orderGenerator.generateOrder(products, 5, 1);
        BigDecimal subtotal = OrderManager.instance().calculateSubtotal(order);
        BigDecimal discountedSubtotal = OrderManager.instance().getFinalAmount(order, PaymentType.VISA);
        BigDecimal discount = new BigDecimal(subtotal.subtract(discountedSubtotal).divide(subtotal)
                .setScale(2, RoundingMode.HALF_EVEN).toPlainString());
        Assertions.assertEquals(new BigDecimal("0.05"), discount);
    }

    @Test
    public void orderWithMastercardDiscount() throws Exception {
        List<Product> products = productGenerator.generateProducts(15);
        Order order = orderGenerator.generateOrder(products, 15, 1);
        BigDecimal subtotal = OrderManager.instance().calculateSubtotal(order);
        BigDecimal discountedSubtotal = OrderManager.instance().getFinalAmount(order, PaymentType.MASTERCARD);
        BigDecimal discount = new BigDecimal(subtotal.subtract(discountedSubtotal).divide(subtotal)
                .setScale(2, RoundingMode.HALF_EVEN).toPlainString());
        if (subtotal.compareTo(new BigDecimal(100)) >= 0) {
            Assertions.assertEquals(new BigDecimal("0.17"), discount);
        } else if (subtotal.compareTo(new BigDecimal("75")) >= 0 && subtotal.compareTo(new BigDecimal("99")) <= 0) {
            Assertions.assertEquals(new BigDecimal("0.12"), discount);
        } else {
            Assertions.assertEquals(new BigDecimal("0.08"), discount);
        }
    }

    @Test
    public void testPutOrder_throwsInvalidOrderException_whenOrderIdIsInvalid() {
        OrderManager orderManager = new OrderManager();
        Order order = new Order();
        assertThrows(InvalidOrderException.class, () -> orderManager.putOrder(0L, order));
    }
}
