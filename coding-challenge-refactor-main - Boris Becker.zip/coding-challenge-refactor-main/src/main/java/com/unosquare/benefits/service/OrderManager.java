package com.unosquare.benefits.service;

import com.unosquare.benefits.entity.Order;
import com.unosquare.benefits.enums.PaymentType;
import com.unosquare.benefits.exceptions.InvalidOrderException;
import com.unosquare.benefits.exceptions.InvalidPaymentTypeException;
import com.unosquare.benefits.exceptions.OrderNotFoundException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;


/**
 * he {@code OrderManager} class is responsible for managing orders in the system.
 * It provides methods for getting, adding and processing orders.
 * <p>This class is a singleton, and it uses the Singleton design pattern to ensure that only one instance of the class is created in the system.
 * <p>The class has a static field {@code orderManager} that holds the unique instance of the class and a static field {@code orderMap} that holds the orders in the system.
 * <p>The class provides methods for:
 * <ul>
 *     <li>{@link #instance()} - returns the unique instance of the class.</li>
 *     <li>{@link #getOrder(long)} - returns an order by the given order id.</li>
 *     <li>{@link #putOrder(long, Order)} - adds an order to the system.</li>
 *     <li>{@link #calculateSubtotal(Order)} - calculates the subtotal of an order.</li>
 *     <li>{@link #applyDiscount(BigDecimal, PaymentType, Order)} - applies a discount to the order based on the payment type.</li>
 *     <li>{@link #getFinalAmount(Order, PaymentType)} - returns the final amount to be paid for an order after applying the discount.</li>
 *     </ul>
 */
public class OrderManager {

    /**
     * Singleton instance of the OrderManager class */
     static OrderManager orderManager = null;

    /**
     * Synchronized method to get the singleton instance of OrderManager.
     *
     * @return the singleton instance of OrderManager.
     */
     synchronized public static OrderManager instance(){
         if (orderManager == null) {
             orderManager = new OrderManager();
         }
         return orderManager;
     }

     private static Map<Long, Order> orderMap = new HashMap<>();

    /**
     * Returns an order with the specified id.
     *
     * @param orderId the id of the order to retrieve.
     * @return the order with the specified id.
     * @throws InvalidOrderException if the order id is less than or equal to 0.
     * @throws OrderNotFoundException if the order is not found in the system.
     */
    public Order getOrder(long orderId) throws InvalidOrderException, OrderNotFoundException {
        if (orderId <= 0)
            throw new InvalidOrderException("Order: " + orderId + " not found");
        Order order = orderMap.get(orderId);
        if (order == null)
            throw new OrderNotFoundException("Order: " + orderId + " not found");
        return order;
    }

    /**
     * Adds an order to the orderMap
     * @param orderId the id of the order to add
     * @param order the order to add
     * @throws InvalidOrderException if the order id is less than or equal to 0
     */
    public void putOrder(long orderId, Order order) throws InvalidOrderException {
        if (orderId <= 0)
            throw new InvalidOrderException("Invalid order with id: " + orderId);

        orderMap.put(orderId, order);
    }

    /**
     * Calculates the subtotal of an order.
     * @param order the order for which to calculate the subtotal
     * @return the subtotal of the order
     */
    public BigDecimal calculateSubtotal(Order order) {
        return order.getOrderItems().stream()
                .map(orderItem -> orderItem.getProduct().getPrice().multiply(new BigDecimal(orderItem.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Applies a discount to the subtotal of an order based on the payment type.
     * @param subtotal the subtotal of the order
     * @param paymentType the type of payment used to calculate the discount
     * @param order the order for which to apply the discount
     * @return the discount applied to the subtotal
     * @throws InvalidPaymentTypeException if the provided payment type is invalid
     */
    public BigDecimal applyDiscount(BigDecimal subtotal, PaymentType paymentType, Order order) throws InvalidPaymentTypeException {
        DiscountCalculator discountCalculator = new DiscountCalculator();
        return  discountCalculator.calculateDiscount(paymentType.name(), subtotal, order);
    }

    /**
     * Calculates the final amount of an order.
     * @param order the order for which to calculate the final amount
     * @param paymentType the type of payment used to calculate the discount
     * @return the final amount of the order
     * @throws InvalidPaymentTypeException if the provided payment type is invalid
     */
    public BigDecimal getFinalAmount(Order order, PaymentType paymentType) throws InvalidPaymentTypeException {
        BigDecimal subtotal = calculateSubtotal(order);
        BigDecimal discount = applyDiscount(subtotal, paymentType, order);
        return subtotal.subtract(discount);
    }

}


