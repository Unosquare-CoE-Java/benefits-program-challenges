package com.unosquare.benefits.entity;

import com.unosquare.benefits.enums.ProductType;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class Product {

    private Long id;

    private String name;

    private BigDecimal price;

    private ProductType productType;
}
