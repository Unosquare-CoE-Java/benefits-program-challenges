package com.unosquare.benefits.service;

import com.unosquare.benefits.entity.Order;
import com.unosquare.benefits.entity.OrderItem;
import com.unosquare.benefits.enums.PaymentType;
import com.unosquare.benefits.exceptions.InvalidPaymentTypeException;
import org.apache.commons.lang3.EnumUtils;

import java.math.BigDecimal;

/**
 * The DiscountCalculator class is responsible for calculating the discount that applies to a given order based on the payment type.
 * It contains methods to calculate discounts for VISA, MASTERCARD and CASH payments.
 *
 * @author  Boris Becker
 * @version 1.0
 */

public class DiscountCalculator {

    /**
     * Calculates the VISA discount for a given order and subtotal.
     * @param order The order for which the discount should be calculated
     * @param subtotal The subtotal for which the discount should be calculated
     * @return The calculated VISA discount
     */
    public BigDecimal calculateVisaDiscount(Order order, BigDecimal subtotal) {
        int totalProductCount = order.getOrderItems().stream()
                .map(OrderItem::getQuantity)
                .reduce(0, Integer::sum);
        BigDecimal discount;
        if (totalProductCount >= 10) {
            discount = new BigDecimal("0.15");
        } else if (totalProductCount >= 7) {
            discount = new BigDecimal("0.10");
        } else {
            discount = new BigDecimal("0.05");
        }
        return subtotal.multiply(discount);
    }

    /**
     * Calculates MasterCard discount for the given subtotal.
     * @param subtotal the subtotal for which the discount is to be calculated.
     * @return the calculated discount as a {@link BigDecimal}
     */
    public BigDecimal calculateMasterCardDiscount(BigDecimal subtotal) {
        BigDecimal discount;
        if (subtotal.compareTo(new BigDecimal(100)) >= 0) {
            discount = subtotal.multiply(new BigDecimal("0.17"));
        } else if (subtotal.compareTo(new BigDecimal("75")) >= 0 && subtotal.compareTo(new BigDecimal("99")) <= 0) {
            discount = subtotal.multiply(new BigDecimal("0.12"));
        } else {
            discount = subtotal.multiply(new BigDecimal("0.08"));
        }
        return discount;
    }


    /**
     * @param subtotal the subtotal of the order
     * @return the subtotal, as no discount is applied
     */
    public BigDecimal calculateCashDiscount(BigDecimal subtotal) {
        return subtotal;
    }

    /**
     * @param paymentType the type of payment used
     * @param subtotal the subtotal of the order
     * @param order the order
     * @return the discount applied to the order based on the paymentType
     * @throws InvalidPaymentTypeException when the payment type is not valid
     */
    public BigDecimal calculateDiscount(String paymentTypeStr, BigDecimal subtotal, Order order) throws InvalidPaymentTypeException {
        PaymentType paymentType;
        if(EnumUtils.isValidEnum(PaymentType.class, paymentTypeStr)){
            paymentType = PaymentType.valueOf(paymentTypeStr);
        }else{
            throw new InvalidPaymentTypeException("Invalid paymentType: " + paymentTypeStr);
        }
        return switch (paymentType) {
            case VISA -> calculateVisaDiscount(order, subtotal);
            case MASTERCARD -> calculateMasterCardDiscount(subtotal);
            case CASH -> calculateCashDiscount(subtotal);
        };
    }
}

