package com.unosquare.benefits.enums;

public enum ProductType {
    BasicNeeds(1,"Basic Needs"),
    WorkTools(2,"Work Tools"),
    Luxury(3,"Luxury");

    private Integer id;
    private String name;

    ProductType(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }
    public String getName() {
        return name;
    }
}
