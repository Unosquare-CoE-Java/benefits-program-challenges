package com.unosquare.benefits.entity;

import lombok.Data;


@Data
public class OrderItem {

    private Long id;

    private Product product;

    private Integer quantity;

    private Long orderId;

    public OrderItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

}

