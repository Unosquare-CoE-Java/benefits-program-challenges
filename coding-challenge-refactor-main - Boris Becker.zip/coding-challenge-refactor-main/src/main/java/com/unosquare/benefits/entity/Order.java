package com.unosquare.benefits.entity;

import com.unosquare.benefits.enums.PaymentType;
import lombok.Data;

import java.util.List;

@Data
public class Order {

    private Long id;

    private PaymentType paymentType;

    private List<OrderItem> orderItems;

    private Payment payment;
}

