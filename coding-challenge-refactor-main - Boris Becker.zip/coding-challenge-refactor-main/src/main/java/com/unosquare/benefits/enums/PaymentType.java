package com.unosquare.benefits.enums;

public enum PaymentType {
    VISA(1,"VISA"),
    MASTERCARD(2,"MASTERCARD"),
    CASH(3,"CASH");

    private Integer id;
    private String name;

    PaymentType(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }
    public String getName() {
        return name;
    }
}
