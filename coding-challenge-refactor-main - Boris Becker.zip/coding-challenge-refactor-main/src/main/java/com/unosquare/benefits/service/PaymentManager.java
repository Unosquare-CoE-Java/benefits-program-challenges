package com.unosquare.benefits.service;

import com.unosquare.benefits.entity.Order;
import com.unosquare.benefits.entity.Payment;
import com.unosquare.benefits.enums.PaymentType;
import com.unosquare.benefits.exceptions.InvalidOrderException;
import com.unosquare.benefits.exceptions.InvalidPaymentTypeException;
import com.unosquare.benefits.exceptions.OrderNotFoundException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * The PaymentManager class is responsible for managing payments.
 * It has the capability to process payments, and maintains a map of payments.
 * The class has a singleton design pattern, where only one instance can be created.
 * @author Boris Becker
 * @version 1.0
 */
public class PaymentManager {

    /**
     * Singleton instance of the PaymentManager class.
     */
    static PaymentManager paymentManager = null;

    /**
     * Returns the singleton instance of the PaymentManager class.
     *
     * @return PaymentManager - the singleton instance of the PaymentManager class.
     */
    synchronized public static PaymentManager instance(){
        if (paymentManager == null) {
            paymentManager = new PaymentManager();
        }
        return paymentManager;
    }

    /**
     * Map to store payments, where the key is the payment id and the value is the Payment object.
     */
    private static Map<Long, Payment> paymentMap = new HashMap<>();
    /**
     * Atomic long variable to generate unique payment id.
     */
    private AtomicLong paymentId = new AtomicLong(1);

    /**
     * Processes a payment for the given order id and payment type.
     *
     * @param orderId - the id of the order for which the payment is being processed
     * @param paymentType - the type of payment being processed
     * @return Payment - the payment object that was processed
     * @throws InvalidPaymentTypeException - thrown when the given payment type is invalid
     * @throws OrderNotFoundException - thrown when the order id is invalid
     * @throws InvalidOrderException - thrown when the order is invalid
     */
    public Payment processPayment(Long orderId, PaymentType paymentType) throws InvalidPaymentTypeException, OrderNotFoundException, InvalidOrderException {
        Order order = OrderManager.instance().getOrder(orderId);

        BigDecimal finalAmount = OrderManager.instance().getFinalAmount(order, paymentType);
        Payment payment = new Payment();
        payment.setId(paymentId.getAndIncrement());
        payment.setOrderId(order.getId());
        payment.setPaymentType(paymentType);
        payment.setAmount(finalAmount);
        paymentMap.put(payment.getId(), payment);
        return payment;
    }

    public Map<Long, Payment> getPaymentMap(){
        return paymentMap;
    }
}


