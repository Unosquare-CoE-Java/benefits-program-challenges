package com.unosquare.benefits.entity;

import com.unosquare.benefits.enums.PaymentType;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class Payment {

    private Long id;

    private BigDecimal amount;

    private Long orderId;

    private PaymentType paymentType;
}

