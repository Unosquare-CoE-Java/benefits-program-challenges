package com.unosquare.benefits.exceptions;


public class InvalidOrderException extends Exception {

    public InvalidOrderException(String msg) {
        super(msg);
    }
}
