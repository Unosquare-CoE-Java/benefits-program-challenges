/*
 * package-info.java
 * 1.0
 * 2022-11-07
 * Copyright 2022 Unosquare
 * Any illegal reproduction of this content will result in immediate legal action.
 */

/**
 * This package contains classes used to increase
 * functionality to test Orders but is not necessarily
 * related to Orders only.
 *
 * @author Emmanuel Huitrado
 * @version 1.0
 */

package coe.unosquare.benefits.util;
