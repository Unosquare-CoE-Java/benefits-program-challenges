/*
 *  OrderTest
 *  1.0
 *  11/8/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.exception.NoProductsOnOrderException;
import coe.unosquare.benefits.payment.PaymentType;
import coe.unosquare.benefits.product.Product;
import coe.unosquare.benefits.util.ProductGenerator;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Map;

import static coe.unosquare.benefits.util.PayOrderSimulator.payOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;

class OrderTest {
    @Test
    void orderWithVisaMoreThan10ProductsDiscountTest() throws NoProductsOnOrderException {
        Map<Product, Integer> products = ProductGenerator.generateProducts(15);
        assertEquals(0.15, payOrder(products, PaymentType.VISA));
    }

    @Test
    void orderWithVisa10ProductsDiscountTest() throws NoProductsOnOrderException {
        Map<Product, Integer> products = ProductGenerator.generateProducts(10);
        assertEquals(0.15, payOrder(products, PaymentType.VISA));
    }

    @Test
    void orderWithVisa7ProductsDiscountTest() throws NoProductsOnOrderException {
        Map<Product, Integer> products = ProductGenerator.generateProducts(7);
        assertEquals(0.10, payOrder(products, PaymentType.VISA));
    }

    @Test
    void orderWithVisaLessThan7ProductsDiscountTest() throws NoProductsOnOrderException {
        Map<Product, Integer> products = ProductGenerator.generateProducts(5);
        assertEquals(0.05, payOrder(products, PaymentType.VISA));
    }

    @Test
    void orderWithMastercardTotalMoreThan100DiscountTest() throws NoProductsOnOrderException {
        Map<Product, Integer> products = ProductGenerator.generateProducts(200.00);
        assertEquals(0.17, payOrder(products, PaymentType.MASTERCARD));
    }

    @Test
    void orderWithMastercardTotalMoreThan75DiscountTest() throws NoProductsOnOrderException {
        Map<Product, Integer> products = ProductGenerator.generateProducts(80.00);
        assertEquals(0.12, payOrder(products, PaymentType.MASTERCARD));
    }

    @Test
    void orderWithMastercardTotalLessThan75DiscountTest() throws NoProductsOnOrderException {
        Map<Product, Integer> products = ProductGenerator.generateProducts(50.00);
        assertEquals(0.08, payOrder(products, PaymentType.MASTERCARD));
    }

    @Test
    void printOrderTest(){
        OutputStream os = new ByteArrayOutputStream();
        System.setOut(new PrintStream(os));
        OrderPrinter.print(new Order(ProductGenerator.generateProducts(3)));
        assertEquals(3, os.toString().split("\n").length);
    }
}
