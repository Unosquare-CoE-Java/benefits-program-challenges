package coe.unosquare.benefits.exception;

/**
 * To be used when trying to pay an Order with no items
 * <tt>NoProductsOnOrderException</tt> will be thrown.
 */
public class NoProductsOnOrderException extends Exception {

    public NoProductsOnOrderException() {
    }

    public NoProductsOnOrderException(String errorMessage) {
        super(errorMessage);
    }
}
