/*
 * package-info.java
 * 1.0
 * 2022-11-29
 * Copyright 2022 Unosquare
 * Any illegal reproduction of this content will result in immediate legal action.
 */

/**
 * This package contains all classes related to order payment operations.
 *
 * @author Jose Paz
 * @version 1.0
 */
package coe.unosquare.benefits.payment;
