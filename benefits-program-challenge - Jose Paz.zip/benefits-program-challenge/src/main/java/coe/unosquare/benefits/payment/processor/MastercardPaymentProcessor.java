package coe.unosquare.benefits.payment.processor;

import coe.unosquare.benefits.exception.NoProductsOnOrderException;
import coe.unosquare.benefits.order.Order;
import coe.unosquare.benefits.payment.PaymentProcessor;

/**
 * Master Card payment type processor, allows this kind of discount based on the total amount
 * of the order
 * <p>
 * 100$+ 17% discount
 * 75$+  12% discount
 * 0$+   8% discount
 */
public class MastercardPaymentProcessor implements PaymentProcessor {

    /**
     * Process the discounts for the order provided using MasterCard rules
     *
     * @param order the order to pay
     * @return the final order value
     * @throws NoProductsOnOrderException No order can be paid if empty
     */
    @Override
    public double pay(final Order order) throws NoProductsOnOrderException {

        final int productCount = order.getProductCount();
        if(productCount==0) throw new NoProductsOnOrderException();
        final double subTotal = order.getSubTotal();
        double discount = 0.08;

        if (subTotal>= 100) {
            discount = 0.17;
        } else if (subTotal>= 75) {
            discount = 0.12;
        }

        return subTotal - subTotal * discount;
    }
}
