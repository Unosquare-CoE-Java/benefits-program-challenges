package coe.unosquare.benefits.order;

/**
 * Allows the order to be printed
 */
public class OrderPrinter {

    /**
     * Print the order provided to console
     *
     * @param order the order to print
     */
     static void print(Order order) {
        order.getProducts().forEach((product, quantity) ->
                System.out.println("Product:{" + product.getName() + ","
                        + product.getPrice() + ","
                        + product.getType()
                        + "},Quantity:" + quantity
                        + ",Total:" + product.getPrice() * quantity));
    }
}
