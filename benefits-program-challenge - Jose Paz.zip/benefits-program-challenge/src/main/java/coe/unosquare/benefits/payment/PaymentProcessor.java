package coe.unosquare.benefits.payment;

import coe.unosquare.benefits.exception.NoProductsOnOrderException;
import coe.unosquare.benefits.order.Order;

/**
 * This allows various types of payment processors to be used indistinctly
 * Declares de method pay to be implemented by payments processors
 */
public interface PaymentProcessor {

    /**
     * Payment method, should return the final order value applying all discounts
     *
     * @param order the order to pay
     * @return the final order value
     * @throws NoProductsOnOrderException No order can be paid if empty
     */
     double pay(Order order) throws NoProductsOnOrderException;
}
