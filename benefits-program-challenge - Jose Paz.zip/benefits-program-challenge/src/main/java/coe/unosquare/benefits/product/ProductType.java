package coe.unosquare.benefits.product;

/**
 * The product type as enum
 */
public enum ProductType {
    BASIC_NEED,
    WORK_TOOL,
    LUXURY
}
