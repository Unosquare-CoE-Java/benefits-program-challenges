package coe.unosquare.benefits.payment;

import coe.unosquare.benefits.payment.processor.MastercardPaymentProcessor;
import coe.unosquare.benefits.payment.processor.VisaPaymentProcessor;

/**
 * The PaymentType enum contains the types of payments and
 * the corresponding Processors as Singletons
 */
public enum PaymentType {
    VISA(new VisaPaymentProcessor()),
    MASTERCARD(new MastercardPaymentProcessor());

    private final PaymentProcessor paymentProcessor;

    PaymentType(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }

    /**
     * Returns the corresponding payment processor implementation
     * @return
     */
    public PaymentProcessor getPaymentProcessor(){
            return paymentProcessor;
    }

}
