/*
 *  NullProductsException
 *  1.0
 *  11/17/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.discount;

/**
 * Null Products Exception
 */
public class NullProductsException extends Exception
{
}
