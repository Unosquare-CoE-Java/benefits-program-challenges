/*
 *  MasterDiscount
 *  1.0
 *  11/17/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.discount;

import coe.unosquare.benefits.product.Product;

import java.util.Map;

/**
 * Discount calculator for Master
 * @author Carlos Roa
 */
public class MasterDiscount extends DiscountCalculator
{

    /**
     * Gets the discount value for Master
     * @param products the list of products added to the order
     * @return the discount value
     */
    @Override
    public Double getDiscount(final Map<Product, Integer> products) throws NullProductsException
    {
        Double discount = 0.08;
        if (products != null)
        {
            if (products.entrySet()
                .stream()
                .mapToDouble(product -> product.getKey().getPrice() * product.getValue())
                .sum() >= 100)
            {
                discount = 0.17;
            }
            else if (products.entrySet().stream()
                .mapToDouble(product -> product.getKey().getPrice() * product.getValue())
                .sum() >= 75)
            {
                discount = 0.12;
            }
        } else {
            throw new NullProductsException();
        }
        return discount;
    }
}
