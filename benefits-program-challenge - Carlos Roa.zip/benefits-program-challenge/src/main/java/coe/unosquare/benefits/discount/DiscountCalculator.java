/*
 *  DiscountCalculator
 *  1.0
 *  11/17/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.discount;

import coe.unosquare.benefits.product.Product;

import java.util.Map;

/**
 * The Discount Calculator
 * @author Carlos Roa
 */
public abstract class DiscountCalculator
{
    /**
     * Gets the discount that is used when getDiscount is not overridden.
     * @param products the list of products added to the order
     * @return the discount value
     */
    public Double getDiscount(final Map<Product, Integer> products) throws NullProductsException
    {
        if (products == null) {
            throw new NullProductsException();
        }
        return 0.0;
    }
}
