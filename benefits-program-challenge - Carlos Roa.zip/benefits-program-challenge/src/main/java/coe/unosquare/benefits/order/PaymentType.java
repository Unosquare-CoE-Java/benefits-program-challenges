/*
 *  Order
 *  1.0
 *  11/8/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

/**
 * Payment type Enum
 * @author Carlos Roa
 */
public enum PaymentType
{
    VISA,
    MASTER,
    ANOTHER,
}
