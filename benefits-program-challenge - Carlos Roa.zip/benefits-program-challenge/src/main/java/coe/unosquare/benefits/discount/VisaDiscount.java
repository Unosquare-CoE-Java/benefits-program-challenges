/*
 *  VisaDiscount
 *  1.0
 *  11/17/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.discount;

import coe.unosquare.benefits.product.Product;

import java.util.Map;

/**
 * Discount calculator for Visa
 * @author Carlos Roa
 */
public class VisaDiscount extends DiscountCalculator
{
    /**
     * Gets the discount value for Visa
     * @param products the list of products added to the order
     * @return the discount value
     */
    @Override
    public Double getDiscount(final Map<Product, Integer> products) throws NullProductsException
    {
        Double discount = 0.05;
        if (products != null)
        {
            if (products.values()
                .stream()
                .reduce(0, (totalProductCount, quantity) -> totalProductCount += quantity) >= 10)
            {
                discount = 0.15;
            }
            else if (products.values()
                .stream()
                .reduce(0, (totalProductCount, quantity) -> totalProductCount += quantity) >= 7)
            {
                discount = 0.10;
            }
        }
        else {
            throw new NullProductsException();
        }
        return discount;
    }
}
