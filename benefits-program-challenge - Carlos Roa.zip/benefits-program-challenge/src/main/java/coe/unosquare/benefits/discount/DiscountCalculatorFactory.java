/*
 *  DiscountCalculatorFactory
 *  1.0
 *  11/17/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.discount;

import coe.unosquare.benefits.order.PaymentType;

/**
 * The Discount Calculator Factory
 * @author Carlos Roa
 */
public class DiscountCalculatorFactory
{
    /**
     * Private constructor
     */
    private DiscountCalculatorFactory() {

    }

    /**
     * Gets the Discount Calculator object
     * @param paymentType Payment Type
     * @return the discount calculator object
     */
    public static DiscountCalculator getDiscountObject(final PaymentType paymentType) {
        DiscountCalculator discount = null;
        if (paymentType.equals(PaymentType.VISA)){
            discount = new VisaDiscount();
        } else if (paymentType.equals(PaymentType.MASTER)) {
            discount = new MasterDiscount();
        } else {
            discount = new AnotherDiscount();
        }
        return discount;
    }
}
