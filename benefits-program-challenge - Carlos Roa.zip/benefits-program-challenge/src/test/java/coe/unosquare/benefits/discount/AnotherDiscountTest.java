/*
 *  AnotherDiscountTest
 *  1.0
 *  11/17/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.discount;

import coe.unosquare.benefits.product.Product;
import coe.unosquare.benefits.util.ProductGenerator;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class AnotherDiscountTest
{
    private DiscountCalculator anotherDiscount = new AnotherDiscount();

    @Test
    public void getDiscountWithEmptyProducts() throws NullProductsException
    {
        final Map<Product, Integer> products = ProductGenerator.generateProducts(0);
        assertEquals(0.0, anotherDiscount.getDiscount(products));
    }

    @Test
    public void getDiscountWithManyProducts() throws NullProductsException
    {
        final Map<Product, Integer> products = ProductGenerator.generateProducts(5);
        assertEquals(0.0, anotherDiscount.getDiscount(products));
    }

    @Test
    public void getDiscountWithNullProducts() throws NullProductsException
    {
        assertThrows(NullProductsException.class, () -> {anotherDiscount.getDiscount(null);});
    }

}
