/*
 *  DiscountCalculatorFactoryTest
 *  1.0
 *  11/17/22, 8:28 PM
 *  Copyright (c) 2022 Unosquare
 *  Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.discount;

import coe.unosquare.benefits.order.PaymentType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class DiscountCalculatorFactoryTest
{
    @Test
    public void returnsPaymentTypeVisa(){
        assertTrue(DiscountCalculatorFactory.getDiscountObject(PaymentType.VISA) instanceof VisaDiscount);
    }

    @Test
    public void returnsPaymentTypeMaster(){
        assertTrue(DiscountCalculatorFactory.getDiscountObject(PaymentType.MASTER) instanceof MasterDiscount);
    }

    @Test
    public void returnsPaymentTypeAnother(){
        assertTrue(DiscountCalculatorFactory.getDiscountObject(PaymentType.ANOTHER) instanceof AnotherDiscount);
    }
}
