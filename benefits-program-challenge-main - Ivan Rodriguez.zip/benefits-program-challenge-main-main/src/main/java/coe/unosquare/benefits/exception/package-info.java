/**
 * This package contains all classes related to custom exceptions.
 *
 * @author Ivan Rodriguez
 * @version 1.0
 */
package coe.unosquare.benefits.exception;