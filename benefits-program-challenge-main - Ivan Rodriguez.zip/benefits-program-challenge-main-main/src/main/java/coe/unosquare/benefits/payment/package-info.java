/**
 * This package contains all classes related to order payments.
 *
 * @author Ivan Rodriguez
 * @version 1.0
 */
package coe.unosquare.benefits.payment;