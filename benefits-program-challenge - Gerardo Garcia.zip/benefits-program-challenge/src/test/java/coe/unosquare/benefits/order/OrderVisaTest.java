/*
 * OrderVisaTest.java
 * 15/11/22 10:11
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import coe.unosquare.benefits.util.ProductGenerator;
import org.junit.jupiter.api.Test;
import java.util.HashMap;
import java.util.Map;
import static coe.unosquare.benefits.util.PayOrderSimulator.payOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Order visa test cases.
 * @author Gerardo Garcia
 * @version 1.0.
 */
public class OrderVisaTest {

    /**
     * Order with more than 10 products discount test.
     */
    @Test
    void orderWithMoreThan10ProductsDiscountTest(){
        Map<Product, Integer> products = ProductGenerator.generateProducts(15);
        OrderVisa order = new OrderVisa(products);
        assertEquals(0.15, payOrder(products, PaymentType.VISA));
    }

    /**
     * Order with 10 products discount test.
     */
    @Test
    void orderWith10ProductsDiscountTest(){
        Map<Product, Integer> products = ProductGenerator.generateProducts(10);
        OrderVisa order = new OrderVisa(products);
        assertEquals(0.15, payOrder(products, PaymentType.VISA));
    }

    /**
     * Order with 7 products discount test.
     */
    @Test
    void orderWith7ProductsDiscountTest(){
        Map<Product, Integer> products = ProductGenerator.generateProducts(7);
        OrderVisa order = new OrderVisa(products);
        assertEquals(0.10, payOrder(products, PaymentType.VISA));
    }

    /**
     * Order with less than 7 products discount test.
     */
    @Test
    void orderWithLessThan7ProductsDiscountTest(){
        Map<Product, Integer> products = ProductGenerator.generateProducts(5);
        OrderVisa order = new OrderVisa(products);
        assertEquals(0.05, payOrder(products, PaymentType.VISA));
    }

    /**
     * Order with products list empty.
     */
    @Test
    void orderWithProductsListEmpty(){
        Map<Product, Integer> products = new HashMap<Product, Integer>();
        assertEquals(0.0, payOrder(products, PaymentType.VISA));
    }
}
