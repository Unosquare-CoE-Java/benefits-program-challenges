/*
 * package-info.java
 * 15/11/22 18:15
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

/**
 * This package contains classes used to increase
 * functionality to test Orders but is not necessarily
 * related to Orders only.
 *
 * @author Gerardo Garcia
 * @version 1.0
 */

package coe.unosquare.benefits.util;
