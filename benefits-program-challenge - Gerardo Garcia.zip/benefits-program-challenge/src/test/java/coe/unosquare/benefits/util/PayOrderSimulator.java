/*
 * PayOrderSimulator.java
 * 15/11/22 18:15
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.util;

import coe.unosquare.benefits.order.Order;
import coe.unosquare.benefits.order.OrderFactory;
import coe.unosquare.benefits.order.PaymentType;
import coe.unosquare.benefits.product.Product;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

/**
 * Pay orders simulator.
 * @author Gerardo Garcia
 * @version 1.0
 */
public final class PayOrderSimulator {
    /**
     * Hide constructor to avoid instances of this utility class.
     */
    private PayOrderSimulator() { }

    /**
     * Method to simulate the process of an order being paid.
     *
     * @param products    the products
     * @param paymentType the payment type
     * @return the double
     */
    public static Double payOrder(final Map<Product, Integer> products,
                                  final PaymentType paymentType) {
        Order order = OrderFactory.getOrder(products, paymentType);
        Double pay = 0.0;
        Double subtotal = products.entrySet()
                            .stream()
                            .mapToDouble(product -> product.getKey().getPrice() * product.getValue())
                            .sum();
        try {
            pay = new BigDecimal((subtotal - order.pay()) / subtotal)
                    .setScale(2, RoundingMode.HALF_EVEN)
                    .doubleValue();
        } catch (NumberFormatException exception) {
            System.err.println(exception.getMessage());
        } finally {
            return pay;
        }
    }
}

