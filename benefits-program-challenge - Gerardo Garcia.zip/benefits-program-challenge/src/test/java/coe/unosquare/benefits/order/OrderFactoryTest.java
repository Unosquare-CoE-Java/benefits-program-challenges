/*
 * OrderFactoryTest.java
 * 15/11/22 10:00
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import org.junit.jupiter.api.Test;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Order factory test cases.
 * @author Gerardo Garcia
 * @version 1.0
 */
public class OrderFactoryTest {

    /**
     * Gets order visa test.
     */
    @Test
    void getOrderVisaTest() {
        Map<Product, Integer> products = new HashMap<Product, Integer>();
        Order order = OrderFactory.getOrder(products, PaymentType.VISA);
        assertTrue(order.getClass().equals(OrderVisa.class));
    }

    /**
     * Gets order mastercard test.
     */
    @Test
    void getOrderMastercardTest() {
        Map<Product, Integer> products = new HashMap<Product, Integer>();
        Order order = OrderFactory.getOrder(products, PaymentType.MASTERCARD);
        assertTrue(order.getClass().equals(OrderMastercard.class));
    }

    /**
     * Gets order no discount test.
     */
    @Test
    void getOrderNoDiscountTest() {
        Map<Product, Integer> products = new HashMap<Product, Integer>();
        Order order = OrderFactory.getOrder(products, PaymentType.OTHER);
        assertTrue(order.getClass().equals(OrderNoDiscount.class));
    }
}
