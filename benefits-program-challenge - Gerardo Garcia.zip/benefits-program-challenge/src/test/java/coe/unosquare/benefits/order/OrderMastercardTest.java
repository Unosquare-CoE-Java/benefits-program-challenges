/*
 * OrderMastercardTest.java
 * 15/11/22 10:04
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import coe.unosquare.benefits.util.ProductGenerator;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static coe.unosquare.benefits.util.PayOrderSimulator.payOrder;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Order mastercard test cases.
 * @author Gerardo Garcia
 * @version 1.0
 */
public class OrderMastercardTest {

    /**
     * Order with sum more than 100 amount discount test.
     */
    @Test
    void orderWithSumMoreThan100AmountDiscountTest() {
        Map<Product, Integer> products = ProductGenerator.generateProducts(100.00);
        OrderMastercard order = new OrderMastercard(products);
        assertEquals(0.17, payOrder(products, PaymentType.MASTERCARD));
    }

    /**
     * Order with sum more than 75 amount discount test.
     */
    @Test
    void orderWithSumMoreThan75AmountDiscountTest() {
        Map<Product, Integer> products = ProductGenerator.generateProducts(75.0);
        OrderMastercard order = new OrderMastercard(products);
        assertEquals(0.12, payOrder(products, PaymentType.MASTERCARD));
    }

    /**
     * Order with sum other amount discount test.
     */
    @Test
    void orderWithSumOtherAmountDiscountTest() {
        Map<Product, Integer> products = ProductGenerator.generateProducts(10.0);
        OrderMastercard order = new OrderMastercard(products);
        assertEquals(0.08, payOrder(products, PaymentType.MASTERCARD));
    }

    /**
     * Order with products list empty.
     */
    @Test
    void orderWithProductsListEmpty(){
        Map<Product, Integer> products = new HashMap<Product, Integer>();
        OrderMastercard order = new OrderMastercard(products);
        assertEquals(0.0, payOrder(products, PaymentType.MASTERCARD));
    }
}
