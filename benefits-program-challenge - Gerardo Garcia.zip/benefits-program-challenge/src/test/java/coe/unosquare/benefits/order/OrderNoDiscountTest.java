/*
 * OrderNoDiscountTest.java
 * 15/11/22 10:03
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import coe.unosquare.benefits.util.ProductGenerator;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Order no discount test cases.
 * @author Gerardo Garcia
 * @version 1.0
 */
public class OrderNoDiscountTest {

    /**
     * Pay method test
     */
    @Test
    void pay() {
        Map<Product, Integer> products = ProductGenerator.generateProducts(50.0);
        OrderNoDiscount order = new OrderNoDiscount(products);
        Double subtotal = 0.0;
        try {
            subtotal = order.getSubtotal();
        } catch(ProductsSizeException exception) {
            System.err.println(exception.getMessage());
        }
        assertTrue ( subtotal >  0);
    }
}
