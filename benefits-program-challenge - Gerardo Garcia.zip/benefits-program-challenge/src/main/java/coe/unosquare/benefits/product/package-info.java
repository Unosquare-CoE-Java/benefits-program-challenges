/*
 * package-info.java
 * 15/11/22 15:58
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

/**
 * This package contains all classes related to Product objects.
 *
 * @author Gerardo Garcia
 * @version 1.0
 */

package coe.unosquare.benefits.product;
