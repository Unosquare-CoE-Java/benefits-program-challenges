/*
 * OrderVisa.java
 * 15/11/22 10:07
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import java.util.Map;

/**
 * Payment Visa Order management.
 * @author Gerardo Garcia
 * @version 1.0
 */
public class OrderVisa extends  Order {

    /**
     * Instantiates a new Order.
     *
     * @param productsMap the list of products added to the order
     */
    public OrderVisa(Map<Product, Integer> productsMap) {
        super(productsMap);
    }

    @Override
    public Double pay(){
        Double discount = 0.0;
        Double pay = 0.0;
        if (getProducts().values()
                .stream()
                .reduce(0, (totalProductCount, quantity) -> totalProductCount += quantity) >= 10) {
            discount = 0.15;
        } else if (getProducts().values()
                .stream()
                .reduce(0, (totalProductCount, quantity) -> totalProductCount += quantity) >= 7) {
            discount = 0.10;
        } else {
            discount = 0.05;
        }
        try {
            pay = getSubtotal() - getSubtotal() * discount;

        } catch (ProductsSizeException exception){
            System.err.println(exception.getMessage());
        } finally {
            return pay;
        }
    }


}
