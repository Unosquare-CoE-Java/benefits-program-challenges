/*
 * OrderMastercard.java
 * 15/11/22 10:05
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import java.util.Map;

/**
 * Payment Mastercard Order management.
 * @author Gerardo Garcia
 * @version 1.0
 */
public class OrderMastercard extends  Order {

    /**
     * Instantiates a new Order.
     *
     * @param productsMap the list of products added to the order
     */
    public OrderMastercard(Map<Product, Integer> productsMap) {
        super(productsMap);
    }

    @Override
    public Double pay(){
        Double discount = 0.0;
        Double pay = 0.0;
        if (getProducts().entrySet()
                .stream()
                .mapToDouble(product -> product.getKey().getPrice() * product.getValue())
                .sum() >= 100) {
            discount = 0.17;
        } else if (getProducts().entrySet().stream()
                .mapToDouble(product -> product.getKey().getPrice() * product.getValue())
                .sum() >= 75) {
            discount = 0.12;
        } else {
            discount = 0.08;
        }
        try {
            pay = getSubtotal() - getSubtotal() * discount;

        } catch (ProductsSizeException exception){
            System.err.println(exception.getMessage());
        } finally {
            return pay;
        }
    }

}
