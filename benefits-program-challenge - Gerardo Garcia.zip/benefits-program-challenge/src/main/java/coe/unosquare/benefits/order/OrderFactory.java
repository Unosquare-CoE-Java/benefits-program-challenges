/*
 * OrderFactory.java
 * 15/11/22 9:54
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import java.util.Map;

/**
 * Factory for Order types (Visa, Mastercard, others - no discount).
 * @author Gerardo Garcia
 * @version 1.0
 */
public class OrderFactory {

    private OrderFactory() {}

    /**
     * Get order by type.
     *
     * @param productsMap the products map
     * @param paymentType the payment type options listed in Enum
     * @return the order (Visa, Mastercard or NoDiscount)
     */
    public static Order getOrder(final Map<Product, Integer> productsMap, final PaymentType paymentType){
        if (paymentType == PaymentType.VISA) {
            return new OrderVisa(productsMap);
        } else if (paymentType == PaymentType.MASTERCARD) {
            return new OrderMastercard(productsMap);
        } else {
            return new OrderNoDiscount(productsMap);
        }
    }
}
