/*
 * ProductsSizeException.java
 * 15/11/22 10:08
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

/**
 * Empty Products list size exception.
 * @author Gerardo Garcia
 * @version 1.0
 */
public class ProductsSizeException extends Exception{

    /**
     * Instantiates a new Products size exception.
     *
     * @param message the message
     */
    public ProductsSizeException(String message) {
        super(message);
    }
}
