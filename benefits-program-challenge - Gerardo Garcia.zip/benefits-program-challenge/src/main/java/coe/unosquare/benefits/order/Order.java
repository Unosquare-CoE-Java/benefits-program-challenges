/*
 * Order.java
 * 15/11/22 9:46
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import java.util.Map;

/**
 * Payment Order management.
 *
 * @author Gerardo Garcia
 * @version 1.0
 */
public abstract class Order {
    /** Store the final list of products and quantity for each product. **/
    private final Map<Product, Integer> products;

    /**
     * Gets products.
     *
     * @return the products
     */
    public Map<Product, Integer> getProducts() {
        return products;
    }

    /**
     * Instantiates a new Order.
     *
     * @param productsMap the list of products added to the order
     */
    public Order(final Map<Product, Integer> productsMap) {
        products = productsMap;
    }

    /**
     * Represents a payment.
     *
     * @return the double
     */
    public abstract  Double pay();

    /**
     * Get subtotal amount.
     *
     * @return the subtotal
     * @throws ProductsSizeException the products size exception
     */
    public Double getSubtotal() throws ProductsSizeException {
        if(products.size() == 0) {
            throw  new ProductsSizeException("Products list is empty");
        }

        return products.entrySet()
                    .stream()
                    .mapToDouble(product -> product.getKey().getPrice() * product.getValue())
                    .sum();
    }
}
