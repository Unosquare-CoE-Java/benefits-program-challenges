/*
 * OrderNoDiscount.java
 * 15/11/22 10:06
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

import coe.unosquare.benefits.product.Product;
import java.util.Map;

/**
 * Payment Other (no discount) Order management.
 *
 * @author Gerardo Garcia
 * @version 1.0
 */
public class OrderNoDiscount extends  Order {

    /**
     * Instantiates a new Order.
     *
     * @param productsMap the list of products added to the order
     */
    public OrderNoDiscount(Map<Product, Integer> productsMap) {
        super(productsMap);
    }

    @Override
    public Double pay(){
        Double pay = 0.0;
        try {
            pay = getSubtotal();
        } catch (ProductsSizeException exception){
            System.err.println(exception.getMessage());
        } finally {
            return pay;
        }
    }
}
