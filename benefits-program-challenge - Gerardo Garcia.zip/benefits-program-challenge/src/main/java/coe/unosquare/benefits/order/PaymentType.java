/*
 * PaymentType.java
 * 15/11/22 10:01
 * Copyright (c) 2022 Unosquare
 * gerardo.garcia
 * Any illegal reproduction of this content will result in immediate legal action.
 */

package coe.unosquare.benefits.order;

/**
 * Payments type Enum.
 * @author Gerardo Garcia
 * @version 1.0
 */
public enum PaymentType {
    /**
     * Visa payment type.
     */
    VISA,
    /**
     * Mastercard payment type.
     */
    MASTERCARD,
    /**
     * Other payment type.
     */
    OTHER
}
