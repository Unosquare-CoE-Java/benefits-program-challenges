/**
 * This package contains all the classes designed to create a new order
 * for different orders
 *
 * @author Miguel Angel Sereno
 * @version 1.0
 */

package coe.unosquare.benefits.order.maker;