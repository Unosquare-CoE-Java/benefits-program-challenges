/**
 * This package contains all the classes related with the types of payments
 * for different orders
 *
 * @author Miguel Angel Sereno
 * @version 1.0
 */
package coe.unosquare.benefits.order.payments;

